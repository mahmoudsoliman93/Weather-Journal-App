# Weather-Journal App Project

## Overview
This project uses a city zip code to get the weater information to this city

## Project Author
Mahmoud Soliman

## Resources

I used some resources to help me to understand more how to do the project and did it with my way as i am a beginner and this is the first time for me to write a code

https://udacity.zoom.us/rec/play/vACWDHXzPEk5DctjUvOU2en9jJMHOU4T9h3tOVBiht7ErHxRErzPuCB6Y7xxpL63aTIMKGD1bHRseMV7.hhQBVe8FKfadeQ7Q?continueMode=true&_x_zm_rtaid=7Gaw2da3RrSkVPhkMr8APA.1667667911009.87e3ad29f33d601e75cfb2e93ea0012f&_x_zm_rhtaid=570

https://www.youtube.com/watch?v=7IvDf6ksjlA&t=229s
