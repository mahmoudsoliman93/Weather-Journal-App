//variables
const zipCode = document.getElementById("zip");
const feeling = document.getElementById("feelings");
const err = document.getElementById("error");
const entry = document.getElementById("entry");
const generateKey = document.getElementById("generate");

//create new date
let date = new Date();
let newDate = date.toDateString();

// Personal API Key for OpenWeatherMap API
const baseURL = "https://api.openweathermap.org/data/2.5/weather?zip=";
const apiKey = ",&appid=bfd077c187fb6097c49110b696e866c1&units=metric";

// server url
const server = "http://localHost:4000";

// generating data
function generateData(e) {
    const zip = zipCode.value;
    const feelings = feeling.value;
    getWeatherData(zip).then(function (data) {
        if (data) {
            const {
                main: { temp },
                name: city,
                weather: [{ description }],
            } = data;

            const info = {
                newDate,
                city,
                temp: Math.round(temp),
                description,
                feelings,
            };

            dataPost(server + "/add", info);

            updateUI();
            entry.style.opacity = 1;
        }
    });
};

/* event listener function */
generateKey.addEventListener("click", generateData);

/* web api data function*/
async function getWeatherData(zip) {
    try {
        const request = await fetch(baseURL + zip + apiKey);
        const response = await request.json();

        if (response.cod != 200) {
            err.innerHTML = response.message;
            setTimeout((_) => (err.innerHTML = ""), 3000);
            throw `${response.message}`;
        }

        return response;
    } catch (err) {
        console.log(err);
    }
};

/* post data function */
async function dataPost(url = "", data = {}) {
    const request = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
    });

    try {
        const response = await request.json();
        console.log(`You saved`, response);
        return response;
    } catch (err) {
        console.log(err);
    }
};

/* GET project data function */
async function updateUI() {
    const request = await fetch(server + "/all");
    try {
        const response = await request.json();

        document.getElementById("city").innerHTML = response.city;
        document.getElementById("date").innerHTML = response.newDate;
        document.getElementById("temp").innerHTML = response.temp + "&degC";
        document.getElementById("content").innerHTML = response.feelings;
        document.getElementById("description").innerHTML = response.description;
    } catch (err) {
        console.log(err);
    }
};
